// Copyright Epic Games, Inc. All Rights Reserved.

#include "GhostsVsThieves.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, GhostsVsThieves, "GhostsVsThieves" );
