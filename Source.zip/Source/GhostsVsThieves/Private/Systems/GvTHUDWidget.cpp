#include "Systems/GvTHUDWidget.h"

void UGvTHUDWidget::HandleLootChanged(int32 NewLoot)
{
	SetLootValue(NewLoot);
}